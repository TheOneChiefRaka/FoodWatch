package com.example.foodwatch.data.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "allergens")
data class Allergen(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val allergenName: String,
    val description: String,
    val type: String
)